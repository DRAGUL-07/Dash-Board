# ML Model Integration Guide (ESP32 / TFLite Micro)

This folder is where your **converted** model file goes. Nothing here is
invented for you — every input shape, class label, and preprocessing step
must come from your own trained model. Sections marked `>>> REPLACE ME`
in `../forest_monitor.ino` are where you plug these details in.

---

## Step 1 — What format does the model need to be in?

TensorFlow Lite for Microcontrollers (TFLite Micro) needs:

1. A **`.tflite`** file (converted from your trained model), then
2. That `.tflite` file converted into a **C byte array** (`model.h`) that
   gets compiled directly into the ESP32 firmware — the ESP32 has no
   filesystem-based model loading by default.

If your model is currently in another format, convert it to `.tflite` first:

| Your model is in... | Conversion path |
|---|---|
| TensorFlow / Keras (`.h5`, SavedModel) | `tf.lite.TFLiteConverter` (native, easiest) |
| PyTorch (`.pt`) | PyTorch → ONNX → TensorFlow → TFLite (use `onnx-tf` or `onnx2tf`) |
| scikit-learn (`.pkl`) | Not directly convertible — you'd re-implement the decision logic (e.g. a small tree or linear model) directly in C++ instead of using TFLite. If your model is a small RandomForest/SVM, it's often easier to hand-port the math than force it through TFLite. |

## Step 2 — Convert to TFLite / TFLite Micro

```python
import tensorflow as tf

# Load your trained Keras model
model = tf.keras.models.load_model("your_model.h5")   # >>> REPLACE ME

converter = tf.lite.TFLiteConverter.from_keras_model(model)

# Recommended for microcontrollers: full integer or float16 quantization
# reduces size significantly. Start with default (float32) if unsure.
converter.optimizations = [tf.lite.Optimize.DEFAULT]

tflite_model = converter.convert()

with open("model.tflite", "wb") as f:
    f.write(tflite_model)
```

If you need **int8 quantization** (smaller, faster, but requires a
representative dataset), see:
https://www.tensorflow.org/lite/performance/post_training_quantization

## Step 3 — Convert `.tflite` to a C array (`model.h`)

```bash
xxd -i model.tflite > model.h
```

Then open `model.h` and:
1. Rename the generated array variable to `g_model` (and the length
   variable to `g_model_len`) so it matches what `forest_monitor.ino`
   expects — or edit the `#include "model/model.h"` line in the .ino to
   match your actual variable names.
2. Add `const` and `alignas(8)` in front of the array declaration for
   correct memory alignment, e.g.:
   ```c
   alignas(8) const unsigned char g_model[] = { 0x1c, 0x00, ... };
   const unsigned int g_model_len = 12345;
   ```

Place the finished `model.h` in this folder (`esp32/model/model.h`).

## Step 4 — Install the Arduino library

In Arduino IDE: **Sketch → Include Library → Manage Libraries** →
search **"TensorFlowLite_ESP32"** → Install.

## Step 5 — Tell the firmware your model's real shape

Back in `forest_monitor.ino`, edit these `>>> REPLACE ME` blocks to match
**exactly** what your model was trained with:

- `MODEL_INPUT_FEATURE_COUNT` — number of input features per inference
- `MODEL_NUM_CLASSES` — number of output classes
- `MODEL_CLASS_LABELS[]` — class names, in the exact order your model
  outputs them (check your training script's label encoder / class_indices)
- `NORM_PARAMS[]` — mean/std (or min/max) used to normalize each feature
  during training — **must match your training preprocessing exactly**,
  or predictions will be meaningless
- `buildFeatureVector()` — must assemble the same features, in the same
  order, as your training data's feature columns
- `kTensorArenaSize` — start at 20KB; increase if `AllocateTensors()` fails

Finally set `USE_TFLITE_MODEL` to `1` at the top of `forest_monitor.ino`.

## Step 6 — Interpreting output / confidence

If your model's final layer is **softmax**, `model_output->data.f[i]` is
already a 0–1 probability per class — the firmware takes the `argmax` as
the prediction and that class's probability as the confidence (already
implemented in `runInference()`).

If your model does **not** end in softmax (raw logits), either:
- add a softmax layer before export, or
- apply softmax manually in `runInference()` before picking the argmax.

## If your model can't run on ESP32 at all

Some models (large transformers, big random forests, anything needing
>~200-300KB of arena) won't fit in ESP32's RAM/flash. In that case:

**Alternative architecture:** ESP32 becomes a pure sensor/data node —
it reads sensors, does the same feature preprocessing, and sends the
**raw feature vector** (not a prediction) to the backend over Wi-Fi.
The Flask/FastAPI backend then loads your full model with regular
TensorFlow/PyTorch/scikit-learn and runs inference server-side, returning
the prediction to be stored and shown on the dashboard.

This requires two small changes:
1. ESP32: skip Section 7 entirely, POST the raw feature vector instead of
   `prediction`/`confidence` fields.
2. Backend: load the model in `app.py` and run `model.predict(...)` inside
   the `POST /api/data` handler before storing the result.

Ask if you want this "server-side inference" variant of `app.py` — it's a
straightforward swap once you know which path you need.
